//
//  SlideMenu.swift
//  Yruha
//
//  Created by Rajesh-MAC on 25/05/18.
//  Copyright © 2018 Rajesh-MAC. All rights reserved.
//


import UIKit

@objc public protocol SlideMenuDelegate {
    
    @objc optional func slideMenuWillOpen()
    @objc optional func slideMenuWillClose()
    @objc optional func slideMenuDidOpen()
    @objc optional func slideMenuDidClose()
    @objc optional func slideMenuShouldOpenSlideMenu () -> Bool
}

@objc public protocol SlideMenuProtocol {
    
    var slideMenu : SlideMenu? { get }
    func setContentViewController(_ contentViewController: UIViewController)
}

public enum SlideMenuAnimation : Int {
    case none
    case `default`
}

public enum SlideMenuPosition : Int {
    case left
    case right
}


public extension UIViewController {
    
    public func toggleSlideMenuView () {
        slideMenuController()?.slideMenu?.toggleMenu()
    }
    
    public func hideSlideMenuView () {
        slideMenuController()?.slideMenu?.hideSlideMenu()
    }
    
    public func showSlideMenuView () {
        slideMenuController()?.slideMenu?.showSlideMenu()
    }
    
    public func isSlideMenuOpen () -> Bool {
        let slideMenuOpen = self.slideMenuController()?.slideMenu?.isMenuOpen
        return slideMenuOpen!
    }
    
    func fixSlideMenuSize() {
        if let navController = self.navigationController as? SlideMenuNavigationController {
            navController.slideMenu?.updateFrame()
        }
    }

    public func slideMenuController () -> SlideMenuProtocol? {
        var iteration : UIViewController? = self.parent
        if (iteration == nil) {
            return topMostController()
        }
        repeat {
            if (iteration is SlideMenuProtocol) {
                return iteration as? SlideMenuProtocol
            } else if (iteration?.parent != nil && iteration?.parent != iteration) {
                iteration = iteration!.parent
            } else {
                iteration = nil
            }
        } while (iteration != nil)
        
        return iteration as? SlideMenuProtocol
    }
    
    internal func topMostController () -> SlideMenuProtocol? {
        var topController : UIViewController? = UIApplication.shared.keyWindow?.rootViewController
        if (topController is UITabBarController) {
            topController = (topController as! UITabBarController).selectedViewController
        }
        var lastMenuProtocol : SlideMenuProtocol?
        while (topController?.presentedViewController != nil) {
            if(topController?.presentedViewController is SlideMenuProtocol) {
                lastMenuProtocol = topController?.presentedViewController as? SlideMenuProtocol
            }
            topController = topController?.presentedViewController
        }
        
        if (lastMenuProtocol != nil) {
            return lastMenuProtocol
        }
        else {
            return topController as? SlideMenuProtocol
        }
    }
}



open class SlideMenu: NSObject, UIGestureRecognizerDelegate {

    open var menuWidth : CGFloat = 160.0 {
        didSet {
            needUpdateApperance = true
            updateSlideMenuApperanceIfNeeded()
            updateFrame()
        }
    }
    
    private var outterView: UIView = UIView()

    fileprivate var menuPosition:SlideMenuPosition = .left
    fileprivate var blurStyle: UIBlurEffect.Style = .light
    
    open var bouncingEnabled :Bool = true
    
    open var animationDuration = 0.4
    fileprivate let slideMenuContainerView =  UIView()
    fileprivate(set) var menuViewController : UIViewController!
    fileprivate var animator : UIDynamicAnimator!
    fileprivate var sourceView : UIView!
    fileprivate var needUpdateApperance : Bool = false
    
    open weak var delegate : SlideMenuDelegate?
    
    fileprivate(set) var isMenuOpen : Bool = false
    
    open var allowLeftSwipe : Bool = true
    open var allowRightSwipe : Bool = true
    open var allowPanGesture : Bool = true
    fileprivate var panRecognizer : UIPanGestureRecognizer?
    
    public init(sourceView: UIView, menuPosition: SlideMenuPosition, blurStyle: UIBlurEffect.Style = .light) {
        super.init()
        self.sourceView = sourceView
        self.menuPosition = menuPosition
        self.blurStyle = blurStyle
        self.setupMenuView()
        
        animator = UIDynamicAnimator(referenceView:sourceView)
        animator.delegate = self
 
        self.panRecognizer = UIPanGestureRecognizer(target: self, action: #selector(SlideMenu.handlePan(_:)))
        panRecognizer!.delegate = self
        sourceView.addGestureRecognizer(panRecognizer!)
        
        let rightSwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(SlideMenu.handleGesture(_:)))
        rightSwipeGestureRecognizer.delegate = self
        rightSwipeGestureRecognizer.direction =  UISwipeGestureRecognizer.Direction.right
        
        let leftSwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(SlideMenu.handleGesture(_:)))
        leftSwipeGestureRecognizer.delegate = self
        leftSwipeGestureRecognizer.direction = UISwipeGestureRecognizer.Direction.left
        
        if (menuPosition == .left) {
            sourceView.addGestureRecognizer(rightSwipeGestureRecognizer)
            slideMenuContainerView.addGestureRecognizer(leftSwipeGestureRecognizer)
        }
        else {
            slideMenuContainerView.addGestureRecognizer(rightSwipeGestureRecognizer)
            sourceView.addGestureRecognizer(leftSwipeGestureRecognizer)
        }
    }

    public convenience init(sourceView: UIView, menuViewController: UIViewController, menuPosition: SlideMenuPosition, blurStyle: UIBlurEffect.Style = .light) {
        
        
        self.init(sourceView: sourceView, menuPosition: menuPosition, blurStyle: blurStyle)
        
        self.menuViewController = menuViewController
        self.menuViewController.view.frame = slideMenuContainerView.bounds
        self.menuViewController.view.autoresizingMask =  [.flexibleHeight, .flexibleWidth]
        slideMenuContainerView.addSubview(self.menuViewController.view)
    }
    
    func updateFrame() {
        var width:CGFloat
        var height:CGFloat
        (width, height) = adjustFrameDimensions( sourceView.frame.size.width, height: sourceView.frame.size.height)
        let menuFrame = CGRect(
            x: (menuPosition == .left) ?
                isMenuOpen ? 0 : -menuWidth-1.0 :
                isMenuOpen ? width - menuWidth : width+1.0,
            y: sourceView.frame.origin.y,
            width: menuWidth,
            height: height
        )
        slideMenuContainerView.frame = menuFrame
    }
    
    fileprivate func adjustFrameDimensions( _ width: CGFloat, height: CGFloat ) -> (CGFloat,CGFloat) {
        if floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_1 &&
            (UIApplication.shared.statusBarOrientation == UIInterfaceOrientation.landscapeRight ||
                UIApplication.shared.statusBarOrientation == UIInterfaceOrientation.landscapeLeft) {
            
            return (height, width)
        }
        else {
            return (width, height)
        }
        
    }
    
    fileprivate func setupMenuView() {
        
        updateFrame()
        
        
        //beefore sideMenuContainerView!
        outterView = UIView(frame: CGRect(x:0, y:0,width:sourceView.frame.width,height:sourceView.frame.height))
        outterView.backgroundColor = UIColor.black
        //outterView.layer.opacity=0.2
        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(SlideMenu.hideSlideMenu))
        outterView.addGestureRecognizer(tapRecognizer)
        outterView.isUserInteractionEnabled = false
        outterView.isHidden = true
        outterView.alpha=0
        sourceView.addSubview(outterView)

        
        slideMenuContainerView.backgroundColor = UIColor.clear
        slideMenuContainerView.clipsToBounds = false
        slideMenuContainerView.layer.masksToBounds = false
        slideMenuContainerView.layer.shadowOffset = (menuPosition == .left) ? CGSize(width: 1.0, height: 1.0) : CGSize(width: -1.0, height: -1.0)
        slideMenuContainerView.layer.shadowRadius = 1.0
        slideMenuContainerView.layer.shadowOpacity = 0.125
        slideMenuContainerView.layer.shadowPath = UIBezierPath(rect: slideMenuContainerView.bounds).cgPath
        
        sourceView.addSubview(slideMenuContainerView)
        
        if (NSClassFromString("UIVisualEffectView") != nil) {
            
            let visualEffectView = UIVisualEffectView(effect: UIBlurEffect(style: blurStyle)) as UIVisualEffectView
            visualEffectView.frame = slideMenuContainerView.bounds
            visualEffectView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
            slideMenuContainerView.addSubview(visualEffectView)
        }
        else {
        }
    }
    
    fileprivate func toggleMenu (_ shouldOpen: Bool) {
        if (shouldOpen && delegate?.slideMenuShouldOpenSlideMenu?() == false) {
            return
        }
        updateSlideMenuApperanceIfNeeded()
        isMenuOpen = shouldOpen
        var width:CGFloat
        var height:CGFloat
        (width, height) = adjustFrameDimensions( sourceView.frame.size.width, height: sourceView.frame.size.height)
        if (bouncingEnabled) {
            
            animator.removeAllBehaviors()
            
            var gravityDirectionX: CGFloat
            var pushMagnitude: CGFloat
            var boundaryPointX: CGFloat
            var boundaryPointY: CGFloat
            
            if (menuPosition == .left) {
                
                gravityDirectionX = (shouldOpen) ? 1 : -1
                pushMagnitude = (shouldOpen) ? 35 : -35
                boundaryPointX = (shouldOpen) ? menuWidth : -menuWidth-2
                boundaryPointY = 25
            }
            else {
                
                gravityDirectionX = (shouldOpen) ? -1 : 1
                pushMagnitude = (shouldOpen) ? -35 : 35
                boundaryPointX = (shouldOpen) ? width-menuWidth : width+menuWidth+2
                boundaryPointY =  -25
            }
            
            let gravityBehavior = UIGravityBehavior(items: [slideMenuContainerView])
            gravityBehavior.gravityDirection = CGVector(dx: gravityDirectionX,  dy: 0)
            animator.addBehavior(gravityBehavior)
            
            let collisionBehavior = UICollisionBehavior(items: [slideMenuContainerView])
            collisionBehavior.addBoundary(withIdentifier: "menuBoundary" as NSCopying, from: CGPoint(x: boundaryPointX, y: boundaryPointY),
                                          to: CGPoint(x: boundaryPointX, y: height))
            animator.addBehavior(collisionBehavior)
            
            let pushBehavior = UIPushBehavior(items: [slideMenuContainerView], mode: UIPushBehavior.Mode.instantaneous)
            pushBehavior.magnitude = pushMagnitude
            animator.addBehavior(pushBehavior)
            
            let menuViewBehavior = UIDynamicItemBehavior(items: [slideMenuContainerView])
            menuViewBehavior.elasticity = 0.25
            animator.addBehavior(menuViewBehavior)
            
        }
        else {
            var destFrame :CGRect
            if (menuPosition == .left) {
                destFrame = CGRect(x: (shouldOpen) ? -2.0 : -menuWidth, y: 0, width: menuWidth, height: height)
            }
            else {
                destFrame = CGRect(x: (shouldOpen) ? width-menuWidth : width+2.0,
                                   y: 0,
                                   width: menuWidth,
                                   height: height)
            }
            
            UIView.animate(
                withDuration: animationDuration,
                animations: { () -> Void in
                    self.slideMenuContainerView.frame = destFrame
            },
                completion: { (Bool) -> Void in
                    if (self.isMenuOpen) {
                        self.delegate?.slideMenuDidOpen?()
                    } else {
                        self.delegate?.slideMenuDidClose?()
                    }
            })
        }
        
        if (shouldOpen) {
            delegate?.slideMenuWillOpen?()
            
            outterView.isUserInteractionEnabled = shouldOpen
            outterView.isHidden = !shouldOpen
            UIView.animate(withDuration: 0.4, delay: 0.0, options: UIView.AnimationOptions.curveEaseIn, animations: {self.outterView.alpha = 0.5}, completion: nil)
            
            
        } else {
            delegate?.slideMenuWillClose?()
            
            UIView.animate(withDuration: 0.4, delay: 0.0, options: UIView.AnimationOptions.curveEaseIn, animations: {self.outterView.alpha = 0.0}, completion: {Void in
                self.outterView.isUserInteractionEnabled = shouldOpen
                self.outterView.isHidden = !shouldOpen
            })
        }
    }
    
    open func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        
        if delegate?.slideMenuShouldOpenSlideMenu?() == false {
            return false
        }
        
        if gestureRecognizer is UISwipeGestureRecognizer {
            let swipeGestureRecognizer = gestureRecognizer as! UISwipeGestureRecognizer
            if !self.allowLeftSwipe {
                if swipeGestureRecognizer.direction == .left {
                    return false
                }
            }
            
            if !self.allowRightSwipe {
                if swipeGestureRecognizer.direction == .right {
                    return false
                }
            }
        }
        else if gestureRecognizer.isEqual(panRecognizer) {
            if allowPanGesture == false {
                return false
            }
            animator.removeAllBehaviors()
            let touchPosition = gestureRecognizer.location(ofTouch: 0, in: sourceView)
            if menuPosition == .left {
                if isMenuOpen {
                    if touchPosition.x < menuWidth {
                        return true
                    }
                }
                else {
                    if touchPosition.x < 25 {
                        return true
                    }
                }
            }
            else {
                if isMenuOpen {
                    if touchPosition.x > sourceView.frame.width - menuWidth {
                        return true
                    }
                }
                else {
                    if touchPosition.x > sourceView.frame.width-25 {
                        return true
                    }
                }
            }
            
            return false
        }
        return true
    }
    
    @objc internal func handleGesture(_ gesture: UISwipeGestureRecognizer) {
        toggleMenu((self.menuPosition == .right && gesture.direction == .left)
            || (self.menuPosition == .left && gesture.direction == .right))
    }
    
    @objc internal func handlePan(_ recognizer : UIPanGestureRecognizer){
        
        let leftToRight = recognizer.velocity(in: recognizer.view).x > 0
        
        switch recognizer.state {
        case .began:
            
            break
            
        case .changed:
            
            let translation = recognizer.translation(in: sourceView).x
            let xPoint : CGFloat = slideMenuContainerView.center.x + translation + (menuPosition == .left ? 1 : -1) * menuWidth / 2
            
            if menuPosition == .left {
                if xPoint <= 0 || xPoint > self.slideMenuContainerView.frame.width {
                    return
                }
            }else{
                if xPoint <= sourceView.frame.size.width - menuWidth || xPoint >= sourceView.frame.size.width
                {
                    return
                }
            }
            
            slideMenuContainerView.center.x = slideMenuContainerView.center.x + translation
            recognizer.setTranslation(CGPoint.zero, in: sourceView)
            
        default:
            
            let shouldClose = menuPosition == .left ? !leftToRight && slideMenuContainerView.frame.maxX < menuWidth : leftToRight && slideMenuContainerView.frame.minX >  (sourceView.frame.size.width - menuWidth)
            
            toggleMenu(!shouldClose)
            
        }
    }
    
    fileprivate func updateSlideMenuApperanceIfNeeded () {
        if (needUpdateApperance) {
            var frame = slideMenuContainerView.frame
            frame.size.width = menuWidth
            slideMenuContainerView.frame = frame
            slideMenuContainerView.layer.shadowPath = UIBezierPath(rect: slideMenuContainerView.bounds).cgPath
            
            needUpdateApperance = false
        }
    }
    
    open func toggleMenu () {
        if (isMenuOpen) {
            toggleMenu(false)
        }
        else {
            updateSlideMenuApperanceIfNeeded()
            toggleMenu(true)
        }
    }
    
    open func showSlideMenu () {
        if (!isMenuOpen) {
            toggleMenu(true)
        }
    }

    @objc open func hideSlideMenu () {
        if (isMenuOpen) {
            toggleMenu(false)
        }
    }

}

extension SlideMenu: UIDynamicAnimatorDelegate {
    
    public func dynamicAnimatorDidPause(_ animator: UIDynamicAnimator) {
        if (self.isMenuOpen) {
            self.delegate?.slideMenuDidOpen?()
        } else {
            self.delegate?.slideMenuDidClose?()
        }
    }
}

