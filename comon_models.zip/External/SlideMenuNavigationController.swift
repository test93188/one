//
//  SlideMenuNavigationController.swift
//  Yruha
//
//  Created by Rajesh-MAC on 25/05/18.
//  Copyright © 2018 Rajesh-MAC. All rights reserved.
//
//


import UIKit

class SlideMenuNavigationController: UINavigationController, SlideMenuProtocol {

    open var slideMenu : SlideMenu?
    open var slideMenuAnimationType : SlideMenuAnimation = .default
    
    
    open override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    public init( menuViewController: UIViewController, contentViewController: UIViewController?) {
        super.init(nibName: nil, bundle: nil)
        
        if (contentViewController != nil) {
            self.viewControllers = [contentViewController!]
        }
        
        slideMenu = SlideMenu(sourceView: self.view, menuViewController: menuViewController, menuPosition:.left)
        view.bringSubviewToFront(navigationBar)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    open override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Navigation
    open func setContentViewController(_ contentViewController: UIViewController) {
        self.slideMenu?.toggleMenu()
        switch slideMenuAnimationType {
        case .none:
            self.viewControllers = [contentViewController]
            break
        default:
            contentViewController.navigationItem.hidesBackButton = false
            self.setViewControllers([contentViewController], animated: true)
            break
        }
        
    }


}
