//
//  CommonVc.swift
//  CareerApp
//
//  Created by Kindlebit on 26/10/18.
//  Copyright © 2018 careerprivacy. All rights reserved.
//

import UIKit
import GoogleSignIn
import Alamofire
import FacebookCore
import GoogleMaps
import GooglePlaces
import AlamofireObjectMapper
import SwiftyJSON

//import GooglePlaces
//import IQKeyboardManagerSwift

extension String {
    func capitalizingFirstLetter() -> String {
        return prefix(1).capitalized + dropFirst()
    }
    
    mutating func capitalizeFirstLetter() {
        self = self.capitalizingFirstLetter()
    }
}

struct CONSTANTS {
    
    struct APPCOLORS {
        static let BLUE = UIColor(8, 22, 141)
    }
    
}

struct APIAddress
{
    static let baseUrl = "http://idryve.kindlebit.com/api/v1/"
    static let CUSTOMER_LOGIN = baseUrl + "auth/login"
    static let CUSTOMER_SIGNUP = baseUrl + "auth/register"
    static let CUST_FORGOT_PWD = baseUrl + "forgot/password"
    static let CHANGE_PASSWORD = baseUrl + "update/update_password"
    static let FACEBOOK_LOGIN = baseUrl + "auth/facebook"
    static let GOOGLE_LOGIN = baseUrl + "auth/google"
    static let OTP_VERIFY = baseUrl + "auth/otp_verify"
    static let OTP_RESEND = baseUrl + "auth/otp_resend"
    static let UPDATE_PROFILE = baseUrl + "profile_update"
    static let ADD_EMERGENCY_CONTACT = baseUrl + "contacts"
    static let ADD_CAR = baseUrl + "cars"
    static let GET_CAR = baseUrl + "cars"
    static let DELETE_CARS = baseUrl + "cars"
    static let GET_SETTINGS = baseUrl + "settings"
    static let GET_PROFILE = baseUrl + "user"
    static let GET_SOS_CONTACTS = baseUrl + "contacts"
    
    static let GET_MY_BOOKINGS = baseUrl + "bookings"
    
    static let START_TRIP = baseUrl + "bookings/ride_start"
    static let END_TRIP = baseUrl + "bookings/ride_end"
    
    static let UPDATE_DEVICE_TOKEN = baseUrl + "device_details"
    
    static let GET_BOOKING_PRICE_ESTIMATION = baseUrl + "bookings/estimate"
    static let GET_NEARBY_DRIVER = baseUrl + "bookings/search"
    static let CHOOSE_NEARBY_DRIVER = baseUrl + "bookings/choose_driver"
    static let SEND_NOTIFICATION_TO_ALL_DRIVER = baseUrl + "bookings/drivers"
    static let USER_HAS_CONFIRMED_RIDE = baseUrl + "bookings/confirm_ride"
    static let USER_HAS_CANCELED_RIDE = baseUrl + "bookings/canceled_by_user"
    
    
    static let GET_TWILIO_TOKEN = baseUrl + "calls/generate_token"
    static let MAKE_TWILIO_CALL = "http://idryve.kindlebit.com/webhook/twilio_voice"
    
    static let UPDATE_LOCATION = baseUrl + "update_location"
    
    static let SOCKET_BASE_URL = "http://idryve.kindlebit.com:3004"
    static let SOCKET_EXCHANGE_LOCATION = SOCKET_BASE_URL + "/sendLatLong"
    static let SOCKET_SHARE_TRIP_WITH_FRIENDS = SOCKET_BASE_URL + "/liveTracking"
    
    static let ADD_RATING_FEEDBACK = baseUrl + "reviews"
    static let GET_DRIVER_REVIEWS = baseUrl + "reviews/driver_review"
    
    static let GET_MY_FRIENDS = baseUrl + "freindship/get_friends"
    static let SEARCH_FRIENDS = baseUrl + "freindship/search"
    static let ADD_FRIEND = baseUrl + "add_friend"
    static let ACCEPT_REJECT_FRIEND_REQUEST = baseUrl + "freindship/accepted"
    static let UNFRIEND_HIM = baseUrl + "freindship/unfriend"
    static let GET_PENDING_REQUESTS = baseUrl + "freindship/pending_request"
    
    static let HELP_US_TO_IMPROVE = baseUrl + "help_improve"
    
    static let START_PAYMENT = baseUrl + "paypal/start_payment"
    static let PAYMENT_LIST = baseUrl + "paypal/get_payment_list"
    
    static let GET_FAV_PLACES = baseUrl + "user/get_place_address"
    static let DELETE_FAV_PLACE = baseUrl + "user/delete_place_address"
    static let SET_FAV_PLACE = baseUrl + "user/place_address"
    
    static let SENT_REQUEST_FOR_PAY_BY_SOMONE = baseUrl + "sent_pay_request"
    static let ACCEPT_REJECT_PAY_FOR_FRIEND = baseUrl + "check_request_status"
    static let SHARE_RIDE_WITH_FRIEND = baseUrl + "bookings/share_trip"
    static let GET_NOTIFICATIONS = baseUrl + "bookings/notifications"
    
    static let CANCEL_BOOKING_BEFORE_ACCEPT = baseUrl + "bookings/booking_cancel"
    
    static let EDIT_CARS_DOCUMENTS = baseUrl + "car/update_cars"
    
}

public class CommonVc: UIViewController {
    
    typealias CompletionUser = ( _ result: Handle_Response? , _ error: Error?) -> ()
    public class AllFunctions
    {
        
        class func get_top_controller()-> UIViewController
        {
            if var topController = UIApplication.shared.keyWindow?.rootViewController
            {
                while let presentedViewController = topController.presentedViewController
                {
                    topController = presentedViewController
                }
                
                return topController
            }
            
            return   UIApplication.shared.keyWindow!.rootViewController!
        }
        
        
        class func GetAppCity()-> String
        {
            var city = "Chicago"
            if((UserDefaults.standard.object(forKey: "AppCity")) != nil)
            {
                city = UserDefaults.standard.value(forKey: "AppCity") as! String
            }
            return city
        }
        class func GetAppLatitude()-> String
        {
            var latitude = "41.881832"
            if((UserDefaults.standard.object(forKey: "AppLatitude")) != nil)
            {
                latitude = UserDefaults.standard.value(forKey: "AppLatitude") as! String
            }
            return latitude
        }
        class func GetAppLongitude()-> String
        {
            var longitude = "-87.623177"
            if((UserDefaults.standard.object(forKey: "AppLongitude")) != nil)
            {
                longitude = UserDefaults.standard.value(forKey: "AppLongitude") as! String
            }
            return longitude
        }
        
        class func AddLatitudeLongitude(lat: String,lng: String)
        {
            UserDefaults.standard.set(lat, forKey: "AppLatitude")
            UserDefaults.standard.set(lng, forKey: "AppLongitude")
        }
        class func GetAppGooglePlaceClicked()-> String
        {
            var place = ""
            if((UserDefaults.standard.object(forKey: "AppPlace")) != nil)
            {
                place = UserDefaults.standard.value(forKey: "AppPlace") as! String
            }
            return place
        }
        
        class func showAlert(message:String,view:UIViewController,title:String)
        {
            let alert = UIAlertController(title: title, message:message, preferredStyle: UIAlertController.Style.alert)
            let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(defaultAction)
            view.present(alert, animated: true, completion: nil)
        }
        class func AppButtonsColor(button: UIButton)
        {
            button.backgroundColor = UIColor(red: 106/255, green: 186/255, blue: 183/255, alpha: 1.0)
        }
        class func fetchCurrentUser() {
            Singleton.shared().facebookUserID = Singleton.shared().facebookUserID
            Singleton.shared().googleUserID = Singleton.shared().googleUserID
            Singleton.shared().googleUserToken = Singleton.shared().googleUserToken
            Singleton.shared().firstName = Singleton.shared().firstName
            Singleton.shared().middleName = Singleton.shared().middleName
            Singleton.shared().lastName = Singleton.shared().lastName
            Singleton.shared().profileImageUrl = Singleton.shared().profileImageUrl
            Singleton.shared().id = Singleton.shared().id
            Singleton.shared().email = Singleton.shared().email
        }
        
        class func image_radious(image: UIImageView)-> UIImageView {
            image.layer.cornerRadius = 3
            image.layer.masksToBounds = true
            image.clipsToBounds = true;
            return image
        }
        class func radious_create(button: UIButton)-> UIButton {
            button.layer.cornerRadius = 5
            button.layer.shadowColor = UIColor.black.cgColor
            button.layer.shadowOffset = CGSize(width: 0, height: 0)
            button.layer.shadowRadius = 5
            button.layer.shadowOpacity = 0.2
            //button.layer.masksToBounds = true
            return button
        }
        class func button_radiousColorborder(button: UIButton)-> UIButton {
            button.layer.cornerRadius = 5
            button.layer.shadowColor = UIColor.black.cgColor
            button.layer.shadowOffset = CGSize(width: 0, height: 0)
            button.layer.shadowRadius = 5
            button.layer.shadowOpacity = 0.2
            //button.layer.masksToBounds = true
            return button
        }
        class func txtfield_border_color(txtfield: UITextField)-> UITextField {
            //txtfield.layer.shadowRadius = 3.0
            txtfield.layer.shadowColor = UIColor.lightGray.cgColor
            txtfield.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
            txtfield.layer.shadowOpacity = 1.0
            
            return txtfield
        }
        class func button_border(button: UIButton)-> UIButton {
            button.layer.borderWidth = 1.0
            button.layer.borderColor = UIColor.white.cgColor
            button.layer.cornerRadius = 20.0
            button.layer.masksToBounds = true
            button.layer.borderWidth = 1.0
            button.layer.borderColor = UIColor.white.cgColor
            
            return button
        }
        
        class func button_shadow_border(button: UIButton)-> UIButton {
            button.layer.shadowColor = UIColor.lightGray.cgColor
            button.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
            button.layer.shadowOpacity = 1.0
            button.layer.cornerRadius = 5.0
            
            return button
        }
        
        class func radious_for_view (view: UIView)->UIView {
            view.layer.cornerRadius = 10.0
            view.layer.shadowColor = UIColor.darkGray.cgColor
            view.layer.shadowOffset = CGSize(width: 0, height: 0)
            view.layer.shadowRadius = 5
            view.layer.shadowOpacity = 0.2
            return view
        }
        class func radious_for_label (label: UILabel)->UILabel {
            label.layer.cornerRadius = 0.0
            label.layer.masksToBounds = true
            label.layer.borderWidth = 2.0
            label.layer.borderColor = UIColor.lightGray.cgColor
            
            return label
        }
        class func radious_for_Button (uibutton: UIButton)->UIButton {
            uibutton.layer.cornerRadius = 0.0
            uibutton.layer.masksToBounds = true
            uibutton.layer.borderWidth = 2.0
            uibutton.layer.borderColor = UIColor.lightGray.cgColor
            
            return uibutton
        }
        class func header_bottom_shedow (view: UIView)->UIView {
            view.layer.shadowColor = UIColor.lightGray.cgColor
            view.layer.masksToBounds = false
            view.layer.shadowOffset = CGSize(width: 0.0 , height: 1.0)
            view.layer.shadowOpacity = 5.0
            view.layer.shadowRadius = 1.0
            return view
        }
        
        class func SearchActiveInactive(button1: UIButton, button2: UIButton,button3: UIButton,button4: UIButton){
            button1.backgroundColor = UIColor(red: 124/255, green: 73/255, blue: 198/255, alpha: 1.0)
            button1.setTitleColor(UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1.0), for:.normal)
            
            button2.backgroundColor = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1.0)
            button2.setTitleColor(UIColor(red: 124/255, green: 73/255, blue: 198/255, alpha: 1.0), for:.normal)
            button3.backgroundColor = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1.0)
            button3.setTitleColor(UIColor(red: 124/255, green: 73/255, blue: 198/255, alpha: 1.0), for:.normal)
            button4.backgroundColor = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1.0)
            button4.setTitleColor(UIColor(red: 124/255, green: 73/255, blue: 198/255, alpha: 1.0), for:.normal)
        }
        class func logout() {
            Singleton.shared().loginManager.logOut()
            GIDSignIn.sharedInstance()?.signOut()
            Singleton.shared().googleUserToken = nil
            Singleton.shared().isGuestUser = false
            Singleton.shared().isGoogleSignIn = false
            Singleton.shared().isFacebookSignIn = false
            Singleton.shared().userIsLoggedIn = false
            Singleton.shared().email = nil
            Singleton.shared().firstName = nil
            Singleton.shared().lastName = nil
            Singleton.shared().middleName = nil
            Singleton.shared().profileImageUrl = nil
            Singleton.shared().id = nil
            
            if let window = UIApplication.shared.keyWindow
            {
                //  let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "NavVC")
                //  window.rootViewController = vc
                //  window.makeKeyAndVisible()
            }
        }
        class func DynamictblHeightAndScroll(cellHeight :CGFloat,tableView : UITableView,ScrollViewTbl: UIScrollView,btnSave: UIButton)
        {
            tableView.frame = CGRect(x: tableView.frame.origin.x, y: tableView.frame.origin.y, width: tableView.frame.size.width, height: cellHeight)
            ScrollViewTbl.contentSize = CGSize(width: ScrollViewTbl.frame.size.width, height: cellHeight+100)
            
            btnSave.frame = CGRect(x: btnSave.frame.origin.x, y: cellHeight+50, width: btnSave.frame.size.width, height: btnSave.frame.size.height)
        }
        class func isValidEmail(testStr:String) -> Bool
        {
            print("validate emilId: \(testStr)")
            let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
            let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
            let result = emailTest.evaluate(with: testStr)
            return result
        }
        class func validatePhone(value: String) -> Bool {
            let PHONE_REGEX = "^[0-9]{9,15}$"
            let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
            let result =  phoneTest.evaluate(with: value)
            return result
        }
        
        class func HeaderWithPOSTRequest(forURL: String, params: [String: AnyObject], showLoader:Bool, viewmain:UIView, success: @escaping (Dictionary<String, AnyObject>) -> Void, failure: @escaping (Error) -> Void)
        {
            if showLoader
            {
                MBProgressHUD.showAdded(to: viewmain, animated: true)
            }
            Alamofire.request(forURL, method: .post, parameters: params,headers:["Accept" : "application/json"]).responseJSON { response in
                if response.result.isSuccess
                {
                    //print(response.result.isSuccess)
                    MBProgressHUD.hide(for: viewmain, animated: true)
                    if let json = response.result.value {
                        success(json as! Dictionary<String, AnyObject>)
                        MBProgressHUD.hide(for: viewmain, animated: true)
                    }
                }
                if response.result.isFailure {
                    let error : Error = response.result.error!
                    failure(error)
                }
                if showLoader
                {
                    MBProgressHUD.hide(for: viewmain, animated: true)
                }
            }
        }
        
        class func HeaderWithGETRequestToken(forURL: String, params: [String: AnyObject], showLoader:Bool,viewmain:UIView, success: @escaping (Dictionary<String, AnyObject>) -> Void, failure: @escaping (Error) -> Void)
        {
            if showLoader
            {
                MBProgressHUD.showAdded(to: viewmain, animated: true)
            }
            Alamofire.request(forURL, method: .get, parameters: params,headers:["authorization" :"Bearer \(ExtensionModel.shared.userAuthToken)" , "Accept" : "application/json"]).responseJSON { response in
                
                if response.result.isSuccess
                {
                    print(response.result.isSuccess)
                    MBProgressHUD.hide(for: viewmain, animated: true)
                    if let json = response.result.value {
                        success(json as! Dictionary<String, AnyObject>)
                        MBProgressHUD.hide(for: viewmain, animated: true)
                    }
                }
                if response.result.isFailure {
                    let error : Error = response.result.error!
                    failure(error)
                }
                if showLoader
                {
                    MBProgressHUD.hide(for: viewmain, animated: true)
                }
            }
        }
        
        
        class func HeaderWithGETRequest(forURL: String, params: [String: AnyObject], showLoader:Bool,viewmain:UIView, success: @escaping (Dictionary<String, AnyObject>) -> Void, failure: @escaping (Error) -> Void)
        {
            if showLoader
            {
                MBProgressHUD.showAdded(to: viewmain, animated: true)
            }
            Alamofire.request(forURL, method: .get, parameters: params,headers:["Accept" : "application/json"]).responseJSON { response in
                
                if response.result.isSuccess
                {
                    print(response.result.isSuccess)
                    MBProgressHUD.hide(for: viewmain, animated: true)
                    if let json = response.result.value {
                        success(json as! Dictionary<String, AnyObject>)
                        MBProgressHUD.hide(for: viewmain, animated: true)
                    }
                }
                if response.result.isFailure {
                    let error : Error = response.result.error!
                    failure(error)
                }
                if showLoader
                {
                    MBProgressHUD.hide(for: viewmain, animated: true)
                }
            }
        }
        
        class func HeaderWithPOSTRequestToken(forURL: String, params: [String: AnyObject], showLoader:Bool, viewmain:UIView, success: @escaping (Dictionary<String, AnyObject>) -> Void, failure: @escaping (Error) -> Void)
        {
            if showLoader
            {
                MBProgressHUD.showAdded(to: viewmain, animated: true)
            }
            print(UserDefaults.standard.value(forKey: "userToken") ?? "")
            print(params)
            Alamofire.request(forURL, method: .post, parameters: params,headers:["authorization" :"Bearer \(ExtensionModel.shared.userAuthToken)" , "Accept" : "application/json"]).responseJSON { response in
                
                if response.result.isSuccess
                {
                    print(response.result.isSuccess)
                    MBProgressHUD.hide(for: viewmain, animated: true)
                    if let json = response.result.value {
                        success(json as! Dictionary<String, AnyObject>)
                        MBProgressHUD.hide(for: viewmain, animated: true)
                    }
                }
                if response.result.isFailure {
                    let error : Error = response.result.error!
                    failure(error)
                }
                if showLoader
                {
                    MBProgressHUD.hide(for: viewmain, animated: true)
                }
            }
        } // close function
        
        
        
        class func HeaderWithDELETERequestToken(forURL: String, params: [String: AnyObject], showLoader:Bool, viewmain:UIView, success: @escaping (Dictionary<String, AnyObject>) -> Void, failure: @escaping (Error) -> Void)
        {
            if showLoader
            {
                MBProgressHUD.showAdded(to: viewmain, animated: true)
            }
            
            print(UserDefaults.standard.value(forKey: "userToken") ?? "")
            print(params)
            
            Alamofire.request(forURL, method: .delete, parameters: params,headers:["authorization" :"Bearer \(ExtensionModel.shared.userAuthToken)" , "Accept" : "application/json"]).responseJSON { response in
                
                if response.result.isSuccess
                {
                    print(response.result.isSuccess)
                    MBProgressHUD.hide(for: viewmain, animated: true)
                    if let json = response.result.value {
                        success(json as! Dictionary<String, AnyObject>)
                        MBProgressHUD.hide(for: viewmain, animated: true)
                    }
                }
                if response.result.isFailure {
                    let error : Error = response.result.error!
                    failure(error)
                }
                if showLoader
                {
                    MBProgressHUD.hide(for: viewmain, animated: true)
                }
            }
        } // close function
        
        
        //-------------------------------------------------------------------------
        
        
        //MODEL FOR POST REQUEST WITH TOKEN
        class func HeaderWithPOSTRequestToken_MODEL(forURL: String, params: [String: AnyObject], showLoader:Bool, viewmain:UIView, success: @escaping (CompletionUser))
        {
            
            print(UserDefaults.standard.value(forKey: "userToken") ?? "")
            print(params)
            Alamofire.request(forURL,method:.post,parameters: params,encoding:URLEncoding.default,headers: ["authorization" :"Bearer \(ExtensionModel.shared.userAuthToken)" , "Accept" : "application/json"]).validate().responseObject{ (response: DataResponse<Handle_Response>) in
                switch(response.result)
                {
                case .success(_):
                    var listDetail: Handle_Response?
                    print(response.result.value!)
                    listDetail =  response.result.value ?? nil
                    success(listDetail,nil)
                    break
                case .failure(_):
                    let error : Error = response.result.error!
                    success(nil,error)
                    
                    break
                }
            }
        }
        
        //MODEL FOR POST REQUEST WITHOUT TOKEN
        class func HeaderWithPOSTRequest_MODEL(forURL: String, params: [String: AnyObject], showLoader:Bool, viewmain:UIView, success: @escaping (CompletionUser))
        {
            if showLoader
            {
                MBProgressHUD.showAdded(to: viewmain, animated: true)
            }
            print(params)
            Alamofire.request(forURL,method:.post,parameters: params,encoding:URLEncoding.default,headers: ["Accept" : "application/json"]).validate().responseObject{ (response: DataResponse<Handle_Response>) in
                switch(response.result)
                {
                case .success(_):
                    var listDetail: Handle_Response?
                    print(response.result.value!)
                    listDetail =  response.result.value ?? nil
                    success(listDetail,nil)
                    break
                case .failure(_):
                    let error : Error = response.result.error!
                    success(nil,error)
                    
                    break
                }
            }
        }
        
        
        
        //MODEL FOR GET REQUEST WITH TOKEN
        class func HeaderWithGETRequestToken_MODEL(forURL: String, params: [String: AnyObject], showLoader:Bool, viewmain:UIView, success: @escaping (CompletionUser))
        {
            if showLoader
            {
                MBProgressHUD.showAdded(to: viewmain, animated: true)
            }
            
            print(UserDefaults.standard.value(forKey: "userToken") ?? "")
            print(params)
            Alamofire.request(forURL,method:.get,parameters: nil,encoding:URLEncoding.default,headers: ["authorization" :"Bearer \(ExtensionModel.shared.userAuthToken)" , "Accept" : "application/json"]).validate().responseObject{ (response: DataResponse<Handle_Response>) in
                switch(response.result)
                {
                case .success(_):
                    var listDetail: Handle_Response?
                    print(response.result.value!)
                    listDetail =  response.result.value ?? nil
                    success(listDetail,nil)
                    break
                case .failure(_):
                    let error : Error = response.result.error!
                    success(nil,error)
                    
                    break
                }
            }
        }
        
        
        //MODEL FOR GET REQUEST WITH TOKEN
        class func HeaderWithGETRequest_MODEL(forURL: String, params: [String: AnyObject], showLoader:Bool, viewmain:UIView, success: @escaping (CompletionUser))
        {
            if showLoader
            {
                MBProgressHUD.showAdded(to: viewmain, animated: true)
            }
            
            print(UserDefaults.standard.value(forKey: "userToken") ?? "")
            print(params)
            Alamofire.request(forURL,method:.get,parameters: params,encoding:URLEncoding.default,headers: ["Accept" : "application/json"]).validate().responseObject{ (response: DataResponse<Handle_Response>) in
                switch(response.result)
                {
                case .success(_):
                    var listDetail: Handle_Response?
                    print(response.result.value!)
                    listDetail =  response.result.value ?? nil
                    success(listDetail,nil)
                    break
                case .failure(_):
                    let error : Error = response.result.error!
                    success(nil,error)
                    
                    break
                }
            }
        }
        
        
        //---------------------------------------------------------------------------------------------
        
        
        class func send_pits_in_api() -> String
        {
            var tempArray = NSMutableArray()
            tempArray = NSMutableArray(array: ExtensionModel.shared.my_pits_mutable)
            var result = ""
            var pit1_lat = ""
            var pit1_long = ""
            var pit2_lat = ""
            var pit2_long = ""
            var pit3_lat = ""
            var pit3_long = ""
            
            if (tempArray.count > 0)
            {
                for i in 0...tempArray.count-1
                {
                    if let dic = tempArray.object(at: i)as? NSDictionary
                    {
                        if (i == 0)
                        {
                            pit1_lat = dic.value(forKey: "lat")as? String ?? ""
                            pit1_long = dic.value(forKey: "long")as? String ?? ""
                        }
                        else if (i == 1)
                        {
                            pit2_lat = dic.value(forKey: "lat")as? String ?? ""
                            pit2_long = dic.value(forKey: "long")as? String ?? ""
                        }
                        else if (i == 2)
                        {
                            pit3_lat = dic.value(forKey: "lat")as? String ?? ""
                            pit3_long = dic.value(forKey: "long")as? String ?? ""
                        }
                    }
                }
                
                if (tempArray.count == 1)
                {
                    result = "\(pit1_lat)/\(pit1_long)"
                }
                else if (tempArray.count == 2)
                {
                    result = "\(pit1_lat)/\(pit1_long),\(pit2_lat)/\(pit2_long)"
                }
                else if (tempArray.count == 3)
                {
                    result = "\(pit1_lat)/\(pit1_long),\(pit2_lat)/\(pit2_long),\(pit3_lat)/\(pit3_long)"
                }
                
            }
            else
            {
                result = ""
            }
            
            
            
            
            return result
        }
        
        
        //MARK:  DRAWING ROUTE ON MAP
        class func DRAW_ROUTE_ON_MAP_FOR_PITS(startLAT:String,startLONG:String,StopLAT:String,stopLONG:String,pitsArray:NSArray,myMap:GMSMapView,polyLINE:GMSPolyline)
        {
          //  myMap.clear()
            var directionURL =  "https://maps.googleapis.com/maps/api/directions/json?origin=\(startLAT),\(startLONG)&destination=\(StopLAT),\(stopLONG)&key=AIzaSyACMxnVzccKPbpGhbqt7ILDXA7H7yPvbMk"
            print(directionURL as Any)
            directionURL += "&mode=" + "drive"
            Alamofire.request(directionURL).responseJSON
                { response in
                    
                    if let JSON = response.result.value
                    {
                        //  MBProgressHUD.hide(for: self.view, animated: true)
                        let mapResponse: [String: AnyObject] = JSON as! [String : AnyObject]
                        
                        let routesArray = (mapResponse["routes"] as? Array) ?? []
                        print(routesArray as Any)
                        
                        let routes = (routesArray.first as? Dictionary<String, AnyObject>) ?? [:]
                        //--------Dash line lat-long for starting point ----------\\
                        let dictArray = (routes["legs"] as? Array) ?? []
                        let dict = (dictArray.first as? Dictionary<String, AnyObject>) ?? [:]
                        let steps = (dict["steps"] as? Array) ?? []
                        
                        
                        let stepsDict = (steps.first as? Dictionary<String, AnyObject>) ?? [:]
                        let startLocation = stepsDict["start_location"]
                        let lat = startLocation?["lat"] as? NSNumber ?? 0.0
                        let lng = startLocation?["lng"] as? NSNumber ?? 0.0
                        
                        let dotCoordinate = CLLocationCoordinate2D(latitude: CLLocationDegrees(truncating: lat), longitude: CLLocationDegrees(truncating: lng))
                        //--------Route polypoints----------\\
                        let overviewPolyline = (routes["overview_polyline"] as? Dictionary<String,AnyObject>) ?? [:]
                        let polypoints = (overviewPolyline["points"] as? String) ?? ""
                        let line  = polypoints
                        CommonVc.AllFunctions.addPolyLine_FOR_PITS(encodedString: line, coordinate:dotCoordinate , dotCoordinate:dotCoordinate, map: myMap, polyline: polyLINE)
                    }
                    
            }
            
        }
        
        
        //MARK:  ADD POLYLINE ON MAP
        class func addPolyLine_FOR_PITS(encodedString: String, coordinate: CLLocationCoordinate2D ,dotCoordinate : CLLocationCoordinate2D,map:GMSMapView,polyline:GMSPolyline)
        {
            let dotPath :GMSMutablePath = GMSMutablePath()
            // add coordinate to your path
            dotPath.add(CLLocationCoordinate2DMake(coordinate.latitude, coordinate.longitude))
            dotPath.add(CLLocationCoordinate2DMake(dotCoordinate.latitude, dotCoordinate.longitude))
            
            let dottedPolyline  = GMSPolyline(path: dotPath)
            dottedPolyline.map = map
            dottedPolyline.strokeWidth = 5.0
            let styles: [Any] = [GMSStrokeStyle.solidColor(UIColor.green), GMSStrokeStyle.solidColor(UIColor.clear)]
            let lengths: [Any] = [10, 5]
            dottedPolyline.spans = GMSStyleSpans(dottedPolyline.path!, styles as! [GMSStrokeStyle], lengths as! [NSNumber], GMSLengthKind.rhumb)
            
            //---------Route Polyline---------\\
            
            let path = GMSMutablePath(fromEncodedPath: encodedString)
            polyline.path = path
            polyline.strokeWidth = 3
            polyline.strokeColor = .blue
            polyline.map = map
            
        }
        
        
        
    }
    
    
    
    
    
}
