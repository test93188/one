//
//  MenuTableViewController.swift
//  Yruha
//
//  Created by Rajesh-MAC on 25/05/18.
//  Copyright © 2018 Rajesh-MAC. All rights reserved.
//

import UIKit
import Drift

class MenuTableViewController: UITableViewController {

   
    @IBOutlet weak var profile_ImgVw: UIImageView!
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet var btnProfile: UIButton!
    
    
    //MARK:  View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        if let userData = Config.kAppDelegate.retrieveDictionary(withKey: "UserData") {
//            lblUsername.text! = userData["name"] as! String
//            let profilePic = userData["avatar"] as? String ?? ""
//            if let url = URL(string : profilePic)
//            {
//                let placeholderImage = #imageLiteral(resourceName: "userplace")
//                profile_ImgVw.af_setImage (
//                    withURL: url,
//                    placeholderImage: placeholderImage,
//                    filter: nil,
//                    imageTransition: .noTransition
//                )
//            }
//        }
        
        tableView.tableFooterView = UIView()
        let notificationSignup = Notification.Name("login_Notification")
        NotificationCenter.default.addObserver(self, selector: #selector(MenuTableViewController.methodOfReceiveLogin), name: notificationSignup, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        let str = ExtensionModel.shared.userImage
        self.profile_ImgVw.sd_setImage(with: URL(string: str))
        profile_ImgVw.layer.cornerRadius = 40
        profile_ImgVw.layer.masksToBounds = true
        self.lblUsername.text = ExtensionModel.shared.userName.capitalizingFirstLetter()
        
        btnProfile.layer.cornerRadius = 10
        btnProfile.layer.masksToBounds = true
    }
    
    
    @IBAction func ACTION_EDITPROFILE(_ sender: Any)
    {
        let destination = storyboard?.instantiateViewController(withIdentifier: "EditProfileVC") as! EditProfileVC
        slideMenuController()?.setContentViewController(destination)
    }
    

 
    @objc func methodOfReceiveLogin(sender:Notification)
    {
//        if let userData = Config.kAppDelegate.retrieveDictionary(withKey: "UserData") {
//            lblUsername.text! = userData["name"] as! String
//            let profilePic = userData["avatar"] as? String ?? ""
//            if let url = URL(string : profilePic)
//            {
//                let placeholderImage = #imageLiteral(resourceName: "userplace")
//                profile_ImgVw.af_setImage (
//                    withURL: url,
//                    placeholderImage: placeholderImage,
//                    filter: nil,
//                    imageTransition: .noTransition
//                )
//            }
//        }
    }
    
   //MARK:  UITableViewDelegate
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
       
        return 14
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if indexPath.row == 0
        {
            return 160
        }
        return 50
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        print(indexPath.row)
        switch indexPath.row
        {
            
        case 1:
            self.go_to_home()
            break

        case 2:
            let destination = storyboard?.instantiateViewController(withIdentifier: "MyPaymentVC") as! MyPaymentVC
            slideMenuController()?.setContentViewController(destination)
            break

        case 3:
            
            let destination = storyboard?.instantiateViewController(withIdentifier: "CarListVC") as! CarListVC
            slideMenuController()?.setContentViewController(destination)
            break

        case 4:
            let destination = storyboard?.instantiateViewController(withIdentifier: "PaymentListVC") as! PaymentListVC
            slideMenuController()?.setContentViewController(destination)
            break

        case 5:
            let destination = storyboard?.instantiateViewController(withIdentifier: "ImproveVC") as! ImproveVC
            slideMenuController()?.setContentViewController(destination)
            break
            
        case 6:
            let destination = storyboard?.instantiateViewController(withIdentifier: "CustEmergencyContactVc") as! CustEmergencyContactVc
            slideMenuController()?.setContentViewController(destination)
            break

        case 7:
            let destination = storyboard?.instantiateViewController(withIdentifier: "NotificationsVC") as! NotificationsVC
            slideMenuController()?.setContentViewController(destination)
            break
        case 8:
            let destination = storyboard?.instantiateViewController(withIdentifier: "CustomerHomeVC") as! CustomerHomeVC
            destination.openMail = true
            slideMenuController()?.setContentViewController(destination)
            break
        case 9:
            let destination = storyboard?.instantiateViewController(withIdentifier: "SettingsVC") as! SettingsVC
            slideMenuController()?.setContentViewController(destination)
            break
        case 10:
            let destination = storyboard?.instantiateViewController(withIdentifier: "TermsAndPolicyVC") as! TermsAndPolicyVC
            destination.privacy = false
            destination.from_signup = false
            slideMenuController()?.setContentViewController(destination)
            break
        case 11:
            let destination = storyboard?.instantiateViewController(withIdentifier: "TermsAndPolicyVC") as! TermsAndPolicyVC
            destination.privacy = true
            destination.from_signup = false
            slideMenuController()?.setContentViewController(destination)
            break
        case 12:
            let destination = storyboard?.instantiateViewController(withIdentifier: "AboutUsVC") as! AboutUsVC
            slideMenuController()?.setContentViewController(destination)
            break
        case 13:
            self.actionSheet()
            break
        default:
            
            
            break
        }
    }

   
    @objc func buttonAction1(sender: UIButton!) {
        print("btn1")
    }
    @objc func buttonAction2(sender: UIButton!) {
        print("btn2")
        self.actionSheet()
    }
     //MARK: Logout Alert!
    func actionSheet()
    {
        let optionMenu = UIAlertController(title: nil, message: "Are you sure you want to Logout?", preferredStyle: .actionSheet)
        let CameraAction = UIAlertAction(title: "Logout", style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            //UserDefaults.standard.removeObject(forKey: "UserData")
            //UserDefaults.standard.removeObject(forKey: "token")
            Singleton.shared().userIsLoggedIn =  false
            CommonVc.AllFunctions.logout()
            
            ExtensionModel.shared.userID = "0"
            ExtensionModel.shared.userName = ""
            ExtensionModel.shared.userEmail = ""
            ExtensionModel.shared.userImage = ""
            ExtensionModel.shared.userAuthToken = ""
            ExtensionModel.shared.userEmergencyNumber = ""
            ExtensionModel.shared.userCarDetails = "0"
            ExtensionModel.shared.userDOB = ""
            ExtensionModel.shared.userHomeAddress = ""
            ExtensionModel.shared.touchID_enable = "0"
            ExtensionModel.shared.userEmail_verified = "0"
            
            ExtensionModel.shared.my_drop_LAT = "00.00"
            ExtensionModel.shared.my_drop_LONG = "00.00"
            ExtensionModel.shared.my_pickup_LAT = "00.00"
            ExtensionModel.shared.my_pickup_LONG = "00.00"
            
            ExtensionModel.shared.my_pickup_address_name = ""
            ExtensionModel.shared.my_drop_address_name =  ""
            
            let arr = NSArray()
            ExtensionModel.shared.my_pits = []
            ExtensionModel.shared.my_pits_mutable = arr
            ExtensionModel.shared.share_trip_frindsArray = arr
            
            
            let payrollDic = NSMutableDictionary()
            ExtensionModel.shared.accepted_driver_payroll = payrollDic
            let payrollDic2 = NSDictionary()
            ExtensionModel.shared.shared_ride_dic = payrollDic2
            
            Drift.logout()
            
            config.kAppdelegate.setRootViewController()
        })
        let DismissAction = UIAlertAction(title: "Cancel", style: .cancel, handler: {
            (alert: UIAlertAction!) -> Void in
            print("Dismiss")
        })
        
        // 4
        optionMenu.addAction(CameraAction)
        optionMenu.addAction(DismissAction)
        
        // 5
        switch UIDevice.current.userInterfaceIdiom {
        case .phone:
            self.present(optionMenu, animated: true, completion: nil)
        // It's an iPhone
        case .pad:
            optionMenu.popoverPresentationController?.sourceView = self.view
            optionMenu.popoverPresentationController?.sourceRect = CGRect(x: 0, y: self.view.bounds.size.height - 300, width: self.view.frame.size.width, height: 300)
            //
            self.present(optionMenu, animated: true, completion: nil)
        // It's an iPad
        default:
            
            optionMenu.popoverPresentationController?.sourceView = self.view
            optionMenu.popoverPresentationController?.sourceRect = CGRect(x: 0, y: self.view.bounds.size.height - 300, width: self.view.frame.size.width, height: 300)
            //
            self.present(optionMenu, animated: true, completion: nil)
            // Uh, oh! What could it be?
        }
    }
    
    
    
    func go_to_home()
    {
        let destination = storyboard?.instantiateViewController(withIdentifier: "CustomerHomeVC") as! CustomerHomeVC
        slideMenuController()?.setContentViewController(destination)
    }
}
