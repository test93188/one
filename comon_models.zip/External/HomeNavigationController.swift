//
//  HomeNavigationController.swift
//  Yruha
//
//  Created by Rajesh-MAC on 25/05/18.
//  Copyright © 2018 Rajesh-MAC. All rights reserved.
//

import UIKit
enum config
{
    static let mainscreen = UIScreen.main.bounds
    static let kAppdelegate = UIApplication.shared.delegate as! AppDelegate
}
class HomeNavigationController: SlideMenuNavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let menuTable = self.storyboard?.instantiateViewController(withIdentifier: "MenuTableViewController") as! MenuTableViewController
        slideMenu = SlideMenu(sourceView: self.view, menuViewController: menuTable, menuPosition:.left)
        //sideMenu?.delegate = self //optional
        
        slideMenu?.menuWidth = config.mainscreen.width * 0.7
        
        // optional, default is 160
        
        slideMenu?.bouncingEnabled = false
        
        //sideMenu?.allowPanGesture = false
        // make navigation bar showing over side menu
        //view.bringSubview(toFront: navigationBar)
    }

 
}
