//
//  Extensions.swift
//  Mysitti
//
//  Created by Mac Mini 102 on 5/13/19.
//  Copyright © 2019 Mysitti. All rights reserved.
//

import UIKit
//import SWRevealViewController

let imageCache = NSCache<AnyObject, AnyObject>()

extension UIImageView {
    
    func loadImagesUsingCache(urlString: String) {
        
//        self.image = nil
        
        //getting cached images
        if let cachedImage = imageCache.object(forKey: urlString as AnyObject) as? UIImage {
            self.image = cachedImage
            return
        }
        
        let url = URL(string: urlString)
        
        let task = URLSession.shared.dataTask(with: url!, completionHandler: { (data, response, error) in
            if error != nil {
                print(error ?? "Downloading Profile Image Failed!")
                return
            }
            
            DispatchQueue.main.async {
                if let downloadedImage = UIImage(data: data!) {
                    imageCache.setObject(downloadedImage, forKey: urlString as AnyObject)
                    self.image = downloadedImage
                }
            }
        })
        task.resume()
    }
    
    func changeImageColor(to color: UIColor) {
        if let currentImage = self.image {
            let img = currentImage.withRenderingMode(.alwaysTemplate)
            self.image = img
            self.tintColor = color
        }
    }
    
}

extension UIView {
    func makeCircular(radius: CGFloat? = nil) {
        self.clipsToBounds = true
        self.layer.masksToBounds = true
        if let radius = radius {
            self.layer.cornerRadius = radius
        } else {
            self.layer.cornerRadius = self.frame.size.width/2
        }
    }
    
    func roundedCorner(with radius: CGFloat,_ topLeft: Bool,_ topRight: Bool,_ bottomLeft: Bool,_ bottomRight: Bool) {
        if #available(iOS 11.0, *) {
            self.layer.cornerRadius = radius
            self.layer.masksToBounds = true
            self.clipsToBounds = true
            
            var corners = CACornerMask()
            if topLeft {
                corners.insert(.layerMinXMinYCorner)
            }
            if topRight {
                corners.insert(.layerMaxXMinYCorner)
            }
            if bottomLeft {
                corners.insert(.layerMinXMaxYCorner)
            }
            if bottomRight {
                corners.insert(.layerMaxXMaxYCorner)
            }
            self.layer.maskedCorners = corners
        } else {
            var corners = UIRectCorner()
            if topLeft {
                corners.insert(.topLeft)
            }
            if topRight {
                corners.insert(.topRight)
            }
            if bottomLeft {
                corners.insert(.bottomLeft)
            }
            if bottomRight {
                corners.insert(.bottomRight)
            }
            let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
            let maskLayer = CAShapeLayer()
            maskLayer.frame = self.bounds
            maskLayer.path = path.cgPath
            self.layer.mask = maskLayer
        }
    }
}

extension UIColor {
    convenience init(_ r: CGFloat,_ g: CGFloat,_ b: CGFloat,_ a: CGFloat = 1) {
        self.init(red: r/255, green: g/255, blue: b/255, alpha: a)
    }
}

extension UIViewController {

    @objc func dismissKeyboardOnViewTap() {
        self.view.isUserInteractionEnabled = true
        self.view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard(_ :))))
    }
    
    @objc private func dismissKeyboard(_ sender: UIGestureRecognizer) {
        self.view.endEditing(true)
    }
    
    @objc func goBackToPreviousScreen() {
        if let navVC = self.navigationController {
            navVC.popViewController(animated: true)
        } else {
            self.dismiss(animated: true, completion: nil)
        }
    }
    
//    @objc func goToHomeScreen() {
//        if let window = UIApplication.shared.keyWindow {
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//            if let navVC = storyboard.instantiateViewController(withIdentifier: "NavVC") as? UINavigationController {
//                if let obj = self.storyboard?.instantiateViewController(withIdentifier: "SideMenuVC") as? SWRevealViewController {
//                    navVC.pushViewController(obj, animated: false)
//                    window.rootViewController = navVC
//                    window.makeKeyAndVisible()
//                } else if let obj = storyboard.instantiateViewController(withIdentifier: "SideMenuVC") as? SWRevealViewController {
//                    navVC.pushViewController(obj, animated: false)
//                    window.rootViewController = navVC
//                    window.makeKeyAndVisible()
//                }
//
//            }
//        }
//    }
    
    struct ToastHolder {
        static var toast: UILabel! = nil
    }
    
    func showToast(message: String) {
        if let window = UIApplication.shared.keyWindow {
            if ToastHolder.toast == nil {
                let width = window.frame.width - 40
                let textLabel = UILabel()
                textLabel.backgroundColor = .black
                textLabel.textColor = .white
                textLabel.text = message
                textLabel.clipsToBounds = true
                textLabel.layer.cornerRadius = 5
                textLabel.numberOfLines = 0
                textLabel.font = UIFont(name: "Avenir", size: 14)
                textLabel.textAlignment = .center
                ToastHolder.toast = textLabel
                let height = textLabel.textHeight(withWidth: width)
                textLabel.frame = CGRect(x: 20, y: window.frame.height, width: width, height: height + 10)
                window.addSubview(textLabel)
                UIView.animate(withDuration: 0.25, animations: {
                    textLabel.transform = CGAffineTransform.init(translationX: 0, y: -height - 40)
                }) { (_) in
                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(message.count)/15, execute: {
                        UIView.animate(withDuration: 0.25, animations: {
                            textLabel.transform = CGAffineTransform.identity
                        }, completion: { (_) in
                            ToastHolder.toast = nil
                            textLabel.removeFromSuperview()
                        })
                    })
                }
            }
        }
    }
}

extension UILabel {
    func textHeight(withWidth width: CGFloat) -> CGFloat {
        guard let text = text else { return 0 }
        return text.height(withWidth: width, font: font)
    }
}

extension String {
    func height(withWidth width: CGFloat, font: UIFont) -> CGFloat {
        let maxSize = CGSize(width: width, height: CGFloat.greatestFiniteMagnitude)
        let actualSize = self.boundingRect(with: maxSize, options: [.usesLineFragmentOrigin], attributes: [.font: font], context: nil)
        return actualSize.height
    }
    
//    public func index(of char: Character) -> Int? {
//        if let idx = characters.index(of: char) {
//            return characters.distance(from: startIndex, to: idx)
//        }
//        return nil
//    }
}
