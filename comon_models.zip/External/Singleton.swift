//
//  Singleton.swift
//  Mysitti
//
//  Created by Mac Mini 102 on 5/10/19.
//  Copyright © 2019 Mysitti. All rights reserved.
//

import UIKit
import FacebookLogin
import CoreLocation
//import SWRevealViewController

@objc @objcMembers class Singleton: NSObject {
    private class var swiftSharedInstance: Singleton {
        struct SingletonStruct {
            static let instance = Singleton()
        }
        return SingletonStruct.instance
    }
    
    private override init() {
        
    }
    
    class func shared() -> Singleton {
        return Singleton.swiftSharedInstance
    }
    
    let loginManager = LoginManager()
    var isGuestUser: Bool = false
    
    var isGoogleSignIn: Bool = false {
        didSet {
            if isGoogleSignIn {
                isFacebookSignIn = false
            }
            UserDefaults.standard.set(isGoogleSignIn, forKey: "isGoogleSignIn")
            
        }
    }
    var isFacebookSignIn: Bool = false {
        didSet {
            if isFacebookSignIn {
                isGoogleSignIn = false
            }
            UserDefaults.standard.set(isFacebookSignIn, forKey: "isFacebookSignIn")
            
        }
    }
    var userIsLoggedIn: Bool {
        set (newValue){
            UserDefaults.standard.set(newValue, forKey: "userIsLoggedIn")
            
        }
        get {
            return UserDefaults.standard.bool(forKey: "userIsLoggedIn")
        }
    }
    var googleUserID: String? {
        set (newValue){
            if let newValue = newValue {
                UserDefaults.standard.set(newValue, forKey: "googleUserID")
                
                loggedInUser.googleUserID = newValue
            } else {
                
                loggedInUser.googleUserID = ""
                
                UserDefaults.standard.removeObject(forKey: "googleUserID")
            }
        }
        get {
            if let googleUserID = UserDefaults.standard.string(forKey: "googleUserID") {
                if googleUserID == "" {
                    return nil
                } else {
                    return googleUserID
                }
            }
            return nil
        }
    }
    var googleUserToken: String? {
        set (newValue){
            if let newValue = newValue {
                UserDefaults.standard.set(newValue, forKey: "googleUserToken")
                
                loggedInUser.googleUserToken = newValue
            } else {
                loggedInUser.googleUserToken = ""
                UserDefaults.standard.removeObject(forKey: "googleUserToken")
            }
        }
        get {
            if let googleUserToken = UserDefaults.standard.string(forKey: "googleUserToken") {
                if googleUserToken == "" {
                    return nil
                } else {
                    return googleUserToken
                }
            }
            return nil
        }
    }
    var facebookUserID: String? {
        set (newValue){
            if let newValue = newValue {
                UserDefaults.standard.set(newValue, forKey: "facebookUserID")
                
                loggedInUser.facebookUserID = newValue
            } else {
                loggedInUser.facebookUserID = ""
                UserDefaults.standard.removeObject(forKey: "facebookUserID")
            }
        }
        get {
            if let facebookUserID = UserDefaults.standard.string(forKey: "facebookUserID") {
                if facebookUserID == "" {
                    return nil
                } else {
                    return facebookUserID
                }
            }
            return nil
        }
    }
    var firstName: String? {
        set (newValue){
            if let newValue = newValue {
                UserDefaults.standard.set(newValue, forKey: "firstName")
                
                //loggedInUser.firstName = newValue
            } else {
                //loggedInUser.firstName = ""
                UserDefaults.standard.removeObject(forKey: "firstName")
            }
        }
        get {
            if let firstName = UserDefaults.standard.string(forKey: "firstName") {
                if firstName == "" {
                    return nil
                } else {
                    return firstName
                }
            }
            return nil
        }
    }
    var middleName: String? {
        set (newValue){
            if let newValue = newValue {
                UserDefaults.standard.set(newValue, forKey: "middleName")
                
                loggedInUser.middleName = newValue
            } else {
                loggedInUser.middleName = ""
                UserDefaults.standard.removeObject(forKey: "middleName")
            }
        }
        get {
            if let middleName = UserDefaults.standard.string(forKey: "middleName") {
                if middleName == "" {
                    return nil
                } else {
                    return middleName
                }
            }
            return nil
        }
    }
    var lastName: String? {
        set (newValue){
            if let newValue = newValue {
                UserDefaults.standard.set(newValue, forKey: "lastName")
                
                loggedInUser.lastName = newValue
            } else {
                loggedInUser.lastName = ""
                UserDefaults.standard.removeObject(forKey: "lastName")
            }
        }
        get {
            if let lastName = UserDefaults.standard.string(forKey: "lastName") {
                if lastName == "" {
                    return nil
                } else {
                    return lastName
                }
            }
            return nil
        }
    }
    var email: String? {
        set (newValue){
            if let newValue = newValue {
                UserDefaults.standard.set(newValue, forKey: "email")
                
                loggedInUser.email = newValue
            } else {
                loggedInUser.email = ""
                UserDefaults.standard.removeObject(forKey: "email")
            }
        }
        get {
            if let email = UserDefaults.standard.string(forKey: "email") {
                if email == "" {
                    return nil
                } else {
                    return email
                }
            }
            return nil
        }
    }
    
    var profileImageUrl: String? {
        set (newValue){
            if let newValue = newValue {
                UserDefaults.standard.set(newValue, forKey: "avatar")
                
                loggedInUser.avatar = newValue
            } else {
                loggedInUser.avatar = ""
                UserDefaults.standard.removeObject(forKey: "avatar")
            }
        }
        get {
            if let profileImageUrl = UserDefaults.standard.string(forKey: "avatar") {
                if profileImageUrl == "" {
                    return nil
                } else {
                    return profileImageUrl
                }
            }
            return nil
        }
    }
    
    var id: Int? {
        set (newValue){
            if let newValue = newValue {
                UserDefaults.standard.set(newValue, forKey: "user_id")
                loggedInUser.id = newValue
            } else {
                loggedInUser.id = 0
                UserDefaults.standard.removeObject(forKey: "user_id")
            }
        }
        get {
            if let id = UserDefaults.standard.value(forKey: "user_id") as? Int {
                if id == 0 {
                    return nil
                } else {
                    return id
                }
            }
            return nil
        }
    }
    
    //Singleton.shared().loggedInUser.facebookUserID
    //var sideVC: SWRevealViewController!
    //var homeVC: HomeVC!
    var userLocation = CLLocation()
    let loggedInUser = User()
}

