//
//  Extensions.swift
//  Hark
//
//  Created by MAC-4 on 05/03/19.
//  Copyright © 2019 KBS. All rights reserved.
//

import UIKit
import SystemConfiguration

class ExtensionModel: NSObject
{
    static let shared = ExtensionModel()
    
    let sharedUserDefault =
        UserDefaults(suiteName: "group.com.pa.iDryveApp")
    
    //MARK: USERID
    var userID: String {
        get
        {
            if let user_Id =  UserDefaults.standard.string(forKey: "userID")
            {
                return user_Id
            }
            else
            {
                return "0"
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "userID")
            UserDefaults.standard.synchronize()
        }
    }
    
    //MARK: USERNAME
    var userName: String
    {
        get
        {
            if let user_Name =  UserDefaults.standard.string(forKey: "userName")
            {
                return user_Name
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "userName")
            UserDefaults.standard.synchronize()
        }
    }
    //MARK: USER IMAGE
    var userImage: String
    {
        get
        {
            if let userProfile_Image =  UserDefaults.standard.string(forKey: "userImage")
            {
                return userProfile_Image
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "userImage")
            UserDefaults.standard.synchronize()
        }
    }
    
    
    //MARK: USER Email
    var userEmail: String
    {
        get
        {
            if let userProfile_Image =  UserDefaults.standard.string(forKey: "userEmail")
            {
                return userProfile_Image
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "userEmail")
            UserDefaults.standard.synchronize()
        }
    }
    
    //MARK: USER DEVICE TOKEN
    var userDeviceToken: String
    {
        get
        {
            if let userProfile_Image =  UserDefaults.standard.string(forKey: "userDeviceToken")
            {
                return userProfile_Image
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "userDeviceToken")
            UserDefaults.standard.synchronize()
        }
    }
    
    //MARK: USER TWILIO TOKEN
    var userTwilioToken: String
    {
        get
        {
            if let userTwilioToken =  UserDefaults.standard.string(forKey: "userTwilioToken")
            {
                return userTwilioToken
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "userTwilioToken")
            UserDefaults.standard.synchronize()
        }
    }
    
    
    //MARK: USER AUTH TOKEN
    var userAuthToken: String
    {
        get
        {
            if let userProfile_Image =  UserDefaults.standard.string(forKey: "userAuthToken")
            {
                return userProfile_Image
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "userAuthToken")
            UserDefaults.standard.synchronize()
        }
    }
    
    //MARK: USER EMERGENCY NUMBER
    var userEmergencyNumber: String
    {
        get
        {
            if let userEmergencyNumber =  UserDefaults.standard.string(forKey: "userEmergencyNumber")
            {
                return userEmergencyNumber
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "userEmergencyNumber")
            UserDefaults.standard.synchronize()
        }
    }
    
    //MARK: USER EMERGENCY NUMBER
    var userDOB: String
    {
        get
        {
            if let userDOB =  UserDefaults.standard.string(forKey: "userDOB")
            {
                return userDOB
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "userDOB")
            UserDefaults.standard.synchronize()
        }
    }
    
    //MARK: USER EMERGENCY NUMBER
    var userHomeAddress: String
    {
        get
        {
            if let userHomeAddress =  UserDefaults.standard.string(forKey: "userHomeAddress")
            {
                return userHomeAddress
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "userHomeAddress")
            UserDefaults.standard.synchronize()
        }
    }
    
    //MARK: USER EMERGENCY NUMBER
    var userCarDetails: String
    {
        get
        {
            if let userCarDetails =  UserDefaults.standard.string(forKey: "userCarDetails")
            {
                return userCarDetails
            }
            else
            {
                return "0"
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "userCarDetails")
            UserDefaults.standard.synchronize()
        }
    }
    
    //MARK: USER EMERGENCY NUMBER
    var userEmail_verified: String
    {
        get
        {
            if let userEmail_verified =  UserDefaults.standard.string(forKey: "userEmail_verified")
            {
                return userEmail_verified
            }
            else
            {
                return "0"
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "userEmail_verified")
            UserDefaults.standard.synchronize()
        }
    }
    
    //MARK: USER EMERGENCY NUMBER
    var touchID_enable: String
    {
        get
        {
            if let touchID_enable =  UserDefaults.standard.string(forKey: "touchID_enable")
            {
                return touchID_enable
            }
            else
            {
                return "0"
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "touchID_enable")
            UserDefaults.standard.synchronize()
        }
    }
    
    //MARK: USER ASKED FOR TOUCH ID
    var asked_for_touchID: String
    {
        get
        {
            if let asked_for_touchID =  UserDefaults.standard.string(forKey: "asked_for_touchID")
            {
                return asked_for_touchID
            }
            else
            {
                return "0"
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "asked_for_touchID")
            UserDefaults.standard.synchronize()
        }
    }
    
    //MARK: TOUCH ID LOGIN PARAMETERS EMAIL
    var touchID_email: String
    {
        get
        {
            if let touchID_email =  UserDefaults.standard.string(forKey: "touchID_email")
            {
                return touchID_email
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "touchID_email")
            UserDefaults.standard.synchronize()
        }
    }
    
    //MARK: TOUCH ID LOGIN PARAMETERS PASSWORD
    var touchID_password: String
    {
        get
        {
            if let touchID_password =  UserDefaults.standard.string(forKey: "touchID_password")
            {
                return touchID_password
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "touchID_password")
            UserDefaults.standard.synchronize()
        }
    }
    
    
    //MARK: NEW ACCEPTED DRIVER PAYROL
    var accepted_driver_payroll: NSMutableDictionary//DONT FORGET TO MAKE IT EMPTY
    {
        get
        {
            if let accepted_driver_payroll =  UserDefaults.standard.object(forKey: "accepted_driver_payroll") as? NSDictionary
            {
                return accepted_driver_payroll.mutableCopy() as! NSMutableDictionary
            }
            else
            {
                let dic = NSMutableDictionary()
                return dic
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "accepted_driver_payroll")
            UserDefaults.standard.synchronize()
        }
    }
    
    var my_drop_LAT: String
    {
        get
        {
            if let my_drop_LAT =  UserDefaults.standard.string(forKey: "my_drop_LAT")
            {
                return my_drop_LAT
            }
            else
            {
                return "00.00"
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "my_drop_LAT")
            UserDefaults.standard.synchronize()
        }
    }
    
    var my_drop_LONG: String
    {
        get
        {
            if let my_drop_LONG =  UserDefaults.standard.string(forKey: "my_drop_LONG")
            {
                return my_drop_LONG
            }
            else
            {
                return "00.00"
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "my_drop_LONG")
            UserDefaults.standard.synchronize()
        }
    }
    
    var my_pickup_LAT: String
    {
        get
        {
            if let my_pickup_LAT =  UserDefaults.standard.string(forKey: "my_pickup_LAT")
            {
                return my_pickup_LAT
            }
            else
            {
                return "00.00"
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "my_pickup_LAT")
            UserDefaults.standard.synchronize()
        }
    }
    
    var my_pickup_LONG: String
    {
        get
        {
            if let my_pickup_LONG =  UserDefaults.standard.string(forKey: "my_pickup_LONG")
            {
                return my_pickup_LONG
            }
            else
            {
                return "00.00"
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "my_pickup_LONG")
            UserDefaults.standard.synchronize()
        }
    }
    
    
    var my_pickup_address_name: String
    {
        get
        {
            if let my_pickup_address_name =  UserDefaults.standard.string(forKey: "my_pickup_address_name")
            {
                return my_pickup_address_name
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "my_pickup_address_name")
            UserDefaults.standard.synchronize()
        }
    }
    
    var my_drop_address_name: String
    {
        get
        {
            if let my_drop_address_name =  UserDefaults.standard.string(forKey: "my_drop_address_name")
            {
                return my_drop_address_name
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "my_drop_address_name")
            UserDefaults.standard.synchronize()
        }
    }
    
    var login_type: String
    {
        get
        {
            if let login_type =  UserDefaults.standard.string(forKey: "login_type")
            {
                return login_type
            }
            else
            {
                return ""
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "login_type")
            UserDefaults.standard.synchronize()
        }
    }
    
    
    
    var my_pits: [String]
    {
        get
        {
            if let my_pits =  UserDefaults.standard.array(forKey: "my_pits") as? [String]
            {
                return my_pits
            }
            else
            {
                return []
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "my_pits")
            UserDefaults.standard.synchronize()
        }
    }
    
    
    var my_pits_mutable: NSArray
    {
        get
        {
            if let my_pits_mutable =  UserDefaults.standard.array(forKey: "my_pits_mutable")
            {
                return my_pits_mutable as NSArray
            }
            else
            {
                let arr = NSArray ()
                return arr
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "my_pits_mutable")
            UserDefaults.standard.synchronize()
        }
    }
    
    
    var share_trip_frindsArray: NSArray
    {
        get
        {
            if let share_trip_frindsArray =  UserDefaults.standard.array(forKey: "share_trip_frindsArray")
            {
                return share_trip_frindsArray as NSArray
            }
            else
            {
                let arr = NSArray ()
                return arr
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "share_trip_frindsArray")
            UserDefaults.standard.synchronize()
        }
    }
    
    
    
    var payfor_someone_dictionary: NSMutableDictionary
    {
        get
        {
            if let payfor_someone_dictionary =  UserDefaults.standard.value(forKey: "payfor_someone_dictionary") as? NSMutableDictionary
            {
                return payfor_someone_dictionary
            }
            else
            {
                let dic = NSMutableDictionary()
                return dic
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "payfor_someone_dictionary")
            UserDefaults.standard.synchronize()
        }
    }
    
    
    var shared_ride_dic: NSDictionary
    {
        get
        {
            if let shared_ride_dic =  UserDefaults.standard.value(forKey: "shared_ride_dic") as? NSDictionary
            {
                return shared_ride_dic
            }
            else
            {
                let dic = NSDictionary()
                return dic
            }
        }
        set
        {
            UserDefaults.standard.set(newValue, forKey: "shared_ride_dic")
            UserDefaults.standard.synchronize()
        }
    }
    
    
    
    
    func setStatusBarStyle(style: UIStatusBarStyle)
    {
        if let statusBar = UIApplication.shared.value(forKey: "statusBar") as? UIView
        {
            statusBar.backgroundColor = style == .lightContent ? UIColor.clear : .white
            statusBar.setValue(style == .lightContent ? UIColor.white : .black, forKey: "foregroundColor")
        }
    }
    
    
    func get_randomString_WithLength (len : Int) -> NSString
    {
        
        let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        let randomString : NSMutableString = NSMutableString(capacity: len)
        for _ in 0..<len
        {
            let length = UInt32 (letters.length)
            let rand = arc4random_uniform(length)
            randomString.appendFormat("%C", letters.character(at: Int(rand)))
        }
        return randomString
    }
    
    func set_theme_color()-> UIColor
    {
        return UIColor(red: 106.0/255.0, green: 186.0/255.0, blue: 183.0/255.0, alpha: 1.0)
    }
    
}


extension String
{
    var isValidEmail: Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        return NSPredicate(format: "SELF MATCHES %@", emailRegEx).evaluate(with: self)
    }
    var isValidPassword: Bool
    {
        let passwordRegex = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z!@#$%^&*()\\-_=+{}|?>.<,:;~`’]{8,}$"
        return NSPredicate(format: "SELF MATCHES %@", passwordRegex).evaluate(with: self)
    }
    var RemoveWhiteSpace : String
    {
        let trimmedString = self.trimmingCharacters(in: .whitespaces)
        return trimmedString
    }
}


//MARK:- UIViewController extensions
extension UIViewController
{
    func showAlertWithMesssage(message:String, VC: UIViewController)
    {
        let alertController = UIAlertController(title: "iDryve", message: message, preferredStyle: .alert)
        let action1 = UIAlertAction(title: "OK", style: .default)
        { (action:UIAlertAction) in
            
        }
        alertController.addAction(action1)
        VC.present(alertController, animated: true, completion: nil)
    }
    
    func makeButton_round(myButton : UIButton,roundValue : CGFloat) -> UIButton
    {
        myButton.layer.cornerRadius = roundValue
        myButton.layer.masksToBounds = true
        return myButton
    }
    
    func hideNAV_BAR (controller : UIViewController)
    {
        controller.navigationController?.isNavigationBarHidden = true
    }
    
    func moveBACK (controller : UIViewController)
    {
        controller.navigationController?.popViewController(animated: true);
    }
   
    
    func push_To_Controller(from_controller:UIViewController,to_Controller:UIViewController)
    {
        from_controller.navigationController?.pushViewController(to_Controller, animated: true)
    }
    
    func getAppDelegate() -> AppDelegate
    {
       let appDelegate = UIApplication.shared.delegate as! AppDelegate
       return appDelegate
    }
    
}


extension UIView
{
    
    // OUTPUT 1
    func dropShadow(scale: Bool = true)
    {
        layer.masksToBounds = false
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.5
        layer.shadowOffset = CGSize(width: -1, height: 1)
        layer.shadowRadius = 1
        
        layer.shadowPath = UIBezierPath(rect: bounds).cgPath
        layer.shouldRasterize = true
        layer.rasterizationScale = scale ? UIScreen.main.scale : 1
    }
    
    // OUTPUT 2
    func dropShadow(color: UIColor, opacity: Float = 0.5, offSet: CGSize, radius: CGFloat = 1, scale: Bool = true) {
        layer.masksToBounds = false
        layer.shadowColor = color.cgColor
        layer.shadowOpacity = opacity
        layer.shadowOffset = offSet
        layer.shadowRadius = radius
        
        layer.shadowPath = UIBezierPath(rect: self.bounds).cgPath
        layer.shouldRasterize = true
        layer.rasterizationScale = scale ? UIScreen.main.scale : 1
    }
}

extension UIButton {
    
    func shake() {
        
        let shake = CABasicAnimation(keyPath: "position")
        shake.duration = 0.1
        shake.repeatCount = 2
        shake.autoreverses = true
        
        let fromPoint = CGPoint(x: center.x - 10, y: center.y)
        let fromValue = NSValue(cgPoint: fromPoint)
        
        let toPoint = CGPoint(x: center.x + 10, y: center.y)
        let toValue = NSValue(cgPoint: toPoint)
        
        shake.fromValue = fromValue
        shake.toValue = toValue
        
        layer.add(shake, forKey: "position")
    }
}



