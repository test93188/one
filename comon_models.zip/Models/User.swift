//
//  User.swift
//  Mysitti
//
//  Created by Mac Mini 102 on 5/13/19.
//  Copyright © 2019 Mysitti. All rights reserved.
//

import UIKit
import ObjectMapper

class User {
    var id: Int = 0
    var facebookUserID: String = ""
    var googleUserToken: String = ""
    var googleUserID: String = ""
    var name: String = ""
    var middleName: String = ""
    var lastName: String = ""
    var fullName: String {
        if middleName == "" {
            return name + " " + lastName
        } else {
            return name + " " + middleName + " " + lastName
        }
    }
    var email: String = ""
    var avatar: String = ""
    var phoneNumber: String = ""
    var address: String = ""
    var country: String = ""
    var state: String = ""
    var city: String = ""
    var zipcode: String = ""
    var token: String = ""
    init() {
        
    }
    
    init(dict: [String: AnyObject]) {
        self.id = dict["id"] as! Int
        self.name = dict["name"] as? String ?? ""
        self.lastName = dict["last_name"] as? String ?? ""
        self.phoneNumber = dict["phone"] as? String ?? ""
        self.address = dict["user_address"] as? String ?? ""
        self.country = dict["country"] as? String ?? ""
        self.state = dict["state"] as? String ?? ""
        self.city = dict["city"] as? String ?? ""
        self.zipcode = dict["zipcode"] as? String ?? ""
        self.email = dict["email"] as? String ?? ""
        self.avatar = dict["avatar"] as? String ?? ""
        self.token = dict["token"] as? String ?? ""
    }
    
}

class phoneContacts {
    var fullname: String = ""
    var email: String = ""
    //var avatar: String = ""
    var phoneNumber: String = ""
    
    init() {
        
    }

    init(dic : [String: AnyObject])
    {
        self.fullname = dic["fullname"] as? String ?? ""
        self.email = dic["email"] as? String ?? ""
        self.phoneNumber = dic["phoneNumber"] as? String ?? ""
    }
    
}

//MY MODEL FOR ADD FRIEND VIEW CONTROLLER
class AddFriendModel: NSObject,Mappable
{
    var id :Int?
    var name : String?
    var email: String?
    var avatar: String?
    var phone: String?
    var address: String?
    
    
    override init()
    {
        super.init()
    }
    
    convenience required init?(map: Map)
    {
        self.init()
    }
    
    func mapping(map: Map)
    {
        id <- map["id"]
        name <- map["name"]
        email <- map["email"]
        avatar <- map["avatar"]
        phone <- map["phone"]
        address <- map["address"]
        
        
    }
}




//MY MODEL FOR ADD FRIEND VIEW CONTROLLER
class myFriendsModel: NSObject,Mappable
{
    var id :Int?
    var name : String?
    var email: String?
    var avatar: String?
    var phone: String?
    var address: String?
    
    override init()
    {
        super.init()
    }
    
    convenience required init?(map: Map)
    {
        self.init()
    }
    
    func mapping(map: Map)
    {
        id <- map["id"]
        name <- map["name"]
        email <- map["email"]
        avatar <- map["avatar"]
        phone <- map["phone"]
        address <- map["address"]
        
    }
}


//MY PAYMENT
class myPaymentsModel: NSObject,Mappable
{
    var id :Int?
    var name : String?
    var email: String?
    var avatar: String?
    var phone: String?
    var address: String?
    var amount: String?
    var booking_id: Int?
    var paykey: String?
    
    
    override init()
    {
        super.init()
    }
    
    convenience required init?(map: Map)
    {
        self.init()
    }
    
    func mapping(map: Map)
    {
        id <- map["id"]
        name <- map["name"]
        email <- map["email"]
        avatar <- map["avatar"]
        phone <- map["phone"]
        address <- map["address"]
        amount <- map["amount"]
        booking_id <- map["booking_id"]
        paykey <- map["paykey"]
        
    }
}

//MY myBookingsHistoryModel
class myBookingsHistoryModel: NSObject,Mappable
{
    var id :Int?
    var name : String?
    var email: String?
    var avatar: String?
    var phone: String?
    var address: String?
    var amount: String?
    var booking_id: Int?
    var status: String?
    
    
    override init()
    {
        super.init()
    }
    
    convenience required init?(map: Map)
    {
        self.init()
    }
    
    func mapping(map: Map)
    {
        id <- map["id"]
        name <- map["name"]
        email <- map["email"]
        avatar <- map["avatar"]
        phone <- map["phone"]
        address <- map["address"]
        amount <- map["amount"]
        booking_id <- map["booking_id"]
        status <- map["status"]
    }
}


